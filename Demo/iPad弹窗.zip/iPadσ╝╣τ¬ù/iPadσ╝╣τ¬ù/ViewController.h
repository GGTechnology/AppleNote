//
//  ViewController.h
//  iPad弹窗
//
//  Created by mingcol on 2019/7/15.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

