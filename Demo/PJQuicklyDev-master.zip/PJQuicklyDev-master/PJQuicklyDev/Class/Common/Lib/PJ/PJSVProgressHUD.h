//
//  PJSVProgressHUD.h
//  PJQuicklyDev
//
//  Created by 飘金 on 2017/4/13.
//  Copyright © 2017年 飘金. All rights reserved.
//

#import <SVProgressHUD/SVProgressHUD.h>

@interface PJSVProgressHUD : SVProgressHUD

@end
