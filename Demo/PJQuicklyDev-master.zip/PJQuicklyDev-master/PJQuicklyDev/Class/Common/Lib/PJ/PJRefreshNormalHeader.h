//
//  OC.h
//  PJQuicklyDev
//
//  Created by 飘金 on 2017/4/12.
//  Copyright © 2017年 飘金. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MJRefresh/MJRefreshNormalHeader.h>
/********用于解决Swift3.0识别不了桥接过来的MJRefreshNormalHeader和MJRefreshAutoNormalFooter**********/
@interface PJRefreshNormalHeader : MJRefreshNormalHeader


@end
