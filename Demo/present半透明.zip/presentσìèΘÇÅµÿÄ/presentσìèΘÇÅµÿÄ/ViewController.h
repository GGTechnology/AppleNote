//
//  ViewController.h
//  present半透明
//
//  Created by mingcol on 2019/7/9.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

