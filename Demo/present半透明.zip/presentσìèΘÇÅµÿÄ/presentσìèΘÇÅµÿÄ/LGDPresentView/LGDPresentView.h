//
//  LGDPresentView.h
//  present半透明
//
//  Created by mingcol on 2019/7/9.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGDPresentView : UIViewController

@end

NS_ASSUME_NONNULL_END
