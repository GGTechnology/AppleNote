//
//  main.m
//  自定义xib
//
//  Created by mingcol on 2019/6/21.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
