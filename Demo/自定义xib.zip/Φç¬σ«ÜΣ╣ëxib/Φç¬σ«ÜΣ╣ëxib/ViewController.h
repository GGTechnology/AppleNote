//
//  ViewController.h
//  自定义xib
//
//  Created by mingcol on 2019/6/21.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

