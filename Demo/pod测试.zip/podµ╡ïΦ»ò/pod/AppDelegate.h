//
//  AppDelegate.h
//  pod
//
//  Created by mingcol on 2019/7/5.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

