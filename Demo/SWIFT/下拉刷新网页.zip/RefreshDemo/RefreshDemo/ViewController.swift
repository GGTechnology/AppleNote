//
//  ViewController.swift
//  RefreshDemo
//
//  Created by mac on 2020/1/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    let refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.scrollView.refreshControl = refreshControl
        webView.scrollView.delegate = self
        webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: nil)
        loadWebView()
    }

    private func loadWebView() {
        webView.load(URLRequest(url: URL(string: "https://www.baidu.com")!))
    }

}
extension ViewController: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if refreshControl.isRefreshing == true {
            loadWebView()
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "estimatedProgress" {
            let newprogress = CGFloat((change?[NSKeyValueChangeKey.newKey] as? NSNumber)?.doubleValue ?? 0.0)
            if newprogress == 1 {
                refreshControl.endRefreshing()
            }
        }
    }
}


