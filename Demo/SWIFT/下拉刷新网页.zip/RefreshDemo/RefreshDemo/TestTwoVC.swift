//
//  TestTwoVC.swift
//  RefreshDemo
//
//  Created by mac on 2020/1/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TestTwoVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if refreshControl?.isRefreshing == true {
            DispatchQueue.global().async {
                Thread.sleep(forTimeInterval: 3)
                DispatchQueue.main.async { [weak self] in
                    self?.refreshControl?.endRefreshing()
                }
            }
        }
    }

}

