//
//  AppDelegate.h
//  视频拍摄
//
//  Created by mingcol on 2019/7/17.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

