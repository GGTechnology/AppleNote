//
//  ViewController.h
//  视频拍摄
//
//  Created by mingcol on 2019/7/17.
//  Copyright © 2019 mingcol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

