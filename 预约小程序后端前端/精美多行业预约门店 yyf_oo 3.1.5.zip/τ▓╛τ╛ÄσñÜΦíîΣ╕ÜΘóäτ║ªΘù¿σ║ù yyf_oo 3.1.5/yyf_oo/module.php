<?php
/**
 * 精美万能预约小程序模块定义
 *
 * @author hsens
 * @url hsens
 */
defined('IN_IA') or exit('Access Denied');

class Yyf_ooModule extends WeModule {



}