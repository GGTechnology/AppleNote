var i = {
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "3.1.5",
    siteroot: "https://www.hsens.com/app/index.php",
    method_design: "3"
};

module.exports = i;